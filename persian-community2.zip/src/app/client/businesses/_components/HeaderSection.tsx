import React from 'react';

export default function HeaderSection() {
  return <div>HeaderSection</div>;
}
