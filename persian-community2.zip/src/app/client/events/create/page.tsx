import React from 'react';
import CreateEventForm from './_components/CreateEventForm/index';

export default function page() {
  return <CreateEventForm />;
}
