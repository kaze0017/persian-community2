'use client';
import React, { useCallback, useRef, useState } from 'react';
import {
  GoogleMap,
  useJsApiLoader,
  Marker,
  InfoWindow,
  Polyline,
} from '@react-google-maps/api';

type LatLng = { lat: number; lng: number };

const libraries: ('drawing' | 'geometry' | 'places')[] = [
  'drawing',
  'geometry',
  'places',
];

interface MarkerData {
  id: string;
  position: LatLng;
  title: string;
  description: string;
  imageUrl: string;
}

// Custom Marker component to better manage state and events
const CustomMarker = ({
  marker,
  openInfo,
  setOpenInfo,
  handleUploadImage,
}: {
  marker: MarkerData;
  openInfo: string | null;
  setOpenInfo: (id: string | null) => void;
  handleUploadImage: (id: string, file: File) => void;
}) => {
  const isOpen = openInfo === marker.id;
  const toggleInfo = () => {
    setOpenInfo(isOpen ? null : marker.id);
  };

  return (
    <Marker key={marker.id} position={marker.position} onClick={toggleInfo}>
      {isOpen && (
        <InfoWindow onCloseClick={() => setOpenInfo(null)}>
          <div style={{ maxWidth: 240 }}>
            <h4>{marker.title}</h4>
            <p style={{ margin: '6px 0' }}>{marker.description}</p>
            {marker.imageUrl && (
              <img
                src={marker.imageUrl}
                alt={marker.title}
                style={{
                  width: '100%',
                  borderRadius: 6,
                  marginBottom: 8,
                }}
              />
            )}
            <input
              type='file'
              accept='image/*'
              onChange={(e) => {
                if (e.target.files?.[0]) {
                  handleUploadImage(marker.id, e.target.files[0]);
                }
              }}
            />
          </div>
        </InfoWindow>
      )}
    </Marker>
  );
};

export default function HikeMapDemo() {
  const { isLoaded, loadError } = useJsApiLoader({
    googleMapsApiKey: process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY!,
    libraries,
  });

  const [path] = useState<LatLng[]>([
    { lat: 46.492, lng: -80.99 },
    { lat: 46.495, lng: -80.987 },
    { lat: 46.497, lng: -80.983 },
    { lat: 46.499, lng: -80.98 },
  ]);

  const [markers, setMarkers] = useState<MarkerData[]>([
    {
      id: '1',
      position: { lat: 46.492, lng: -80.99 },
      title: 'Trail Start',
      description: 'Starting point near the lake parking area.',
      imageUrl:
        'https://upload.wikimedia.org/wikipedia/commons/6/6e/Lake_view_trail.jpg',
    },
    {
      id: '2',
      position: { lat: 46.497, lng: -80.983 },
      title: 'Scenic View',
      description: 'Great spot to rest and take photos.',
      imageUrl:
        'https://upload.wikimedia.org/wikipedia/commons/d/df/Hiking_trail_forest.jpg',
    },
    {
      id: '3',
      position: { lat: 46.499, lng: -80.98 },
      title: 'Trail End',
      description: 'End of the trail near the lookout point.',
      imageUrl:
        'https://upload.wikimedia.org/wikipedia/commons/3/3e/Mountain_trail_lookout.jpg',
    },
  ]);

  const [openInfo, setOpenInfo] = useState<string | null>(null);

  const handleUploadImage = (markerId: string, file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      setMarkers((prev) =>
        prev.map((m) =>
          m.id === markerId ? { ...m, imageUrl: reader.result as string } : m
        )
      );
    };
    reader.readAsDataURL(file);
  };

  const mapRef = useRef<google.maps.Map | null>(null);
  const onMapLoad = useCallback((map: google.maps.Map) => {
    mapRef.current = map;
  }, []);

  if (loadError) return <div>Map load error</div>;
  if (!isLoaded) return <div>Loading map...</div>;

  return (
    <div style={{ height: '600px', width: '100%' }}>
      <GoogleMap
        onLoad={onMapLoad}
        mapContainerStyle={{ height: '100%', width: '100%' }}
        center={{ lat: 46.495, lng: -80.986 }}
        zoom={14}
      >
        <Polyline
          path={path}
          options={{
            strokeWeight: 5,
            strokeColor: '#34a853',
            editable: false,
          }}
        />

        {markers.map((m) => (
          <CustomMarker
            key={m.id}
            marker={m}
            openInfo={openInfo}
            setOpenInfo={setOpenInfo}
            handleUploadImage={handleUploadImage}
          />
        ))}
      </GoogleMap>
    </div>
  );
}
