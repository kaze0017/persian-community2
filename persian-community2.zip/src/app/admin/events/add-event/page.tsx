// app/admin/create-event/page.tsx
import CreateEventForm from '@/app/admin/events/add-event/components/CreateEventForm';

export default function CreateEventPage() {
  return <CreateEventForm />;
}
