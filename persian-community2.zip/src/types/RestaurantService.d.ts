export type RestaurantService = {
  id: string;
  name: string;
  description: string;
  banner: string;
};

