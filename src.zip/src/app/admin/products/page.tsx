// pages/products.tsx or wherever you want

import ProductsPage from './productsTemplate/restaurantComponents/ProductsPage';

export default function Products() {
  const businessId = 'AtvzoHHD9hhRPLM9zIKw'; // dynamic or prop

  return <ProductsPage businessId={businessId} />;
}
// You can replace the hardcoded businessId with a dynamic value based on your app's routing or state management.
