import React from 'react';

function DefaultProducts() {
  return <div>DefaultProducts</div>;
}

export default DefaultProducts;
