import React from 'react';
import GlassPanel from '@/components/GlassPanel';
import { TabsContent } from '@/components/ui/tabs';

export default function UiTab() {
  return (
    <TabsContent value='ui'>
      <GlassPanel>
        <div className='space-y-4'>
          <h3 className='text-xl font-semibold'>UI Settings</h3>
          <p className='text-sm/6 text-muted-foreground'>
            Theme, colors, fonts, and layout preferences.
          </p>
          <div className='grid grid-cols-1 sm:grid-cols-2 gap-4'>
            <MiniControl label='Primary Color'>
              <input
                type='color'
                className='h-10 w-full rounded-lg bg-transparent'
              />
            </MiniControl>
            <MiniControl label='Font Size'>
              <select className='h-10 w-full rounded-lg bg-white/10 dark:bg-white/10 backdrop-blur-md border border-white/20 px-3'>
                <option value='sm'>Small</option>
                <option value='base'>Base</option>
                <option value='lg'>Large</option>
              </select>
            </MiniControl>
          </div>
        </div>
      </GlassPanel>
    </TabsContent>
  );
}
function MiniControl({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className='block'>
      <span className='text-xs uppercase tracking-wide text-foreground/80'>
        {label}
      </span>
      <div className='mt-2'>{children}</div>
    </label>
  );
}
