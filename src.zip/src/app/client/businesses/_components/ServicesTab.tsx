import React from 'react';
import GlassPanel from '@/components/GlassPanel';
import { TabsContent } from '@/components/ui/tabs';
import TabTitle from './_subComponents/TabTitle';
import Image from 'next/image';
import AddServicesDialog, { Service } from './_subComponents/AddServicesDialog';
import { filter } from '@/app/components/filters/logoFilter';

export default function ServicesTab() {
  const [services, setServices] = React.useState<Service[]>([]);
  const [isAdding, setIsAdding] = React.useState(false);

  const handleAddService = () => {
    setIsAdding(true);
  };

  const handleSave = (item: Service) => {
    setServices((prev) => [...prev, item]);
    setIsAdding(false);
  };

  return (
    <TabsContent value='services'>
      <GlassPanel>
        <TabTitle
          title='Available Services'
          hasAddBtn
          onAddType={handleAddService}
          addBtnTitle='Add New Service'
        />

        {isAdding && (
          <AddServicesDialog
            open={isAdding}
            onClose={() => setIsAdding(false)}
            onAdded={handleSave}
            businessId='businessId'
          />
        )}

        {services.length === 0 ? (
          <p className='text-sm text-muted-foreground mt-4'>
            No services added yet. Click "Add New Service" to get started.
          </p>
        ) : (
          <ul className='mt-4 space-y-4'>
            {services.map((service) => (
              <li
                key={service.id}
                className='border-b border-foreground py-2 flex sm:flex-col md:flex-row items-start'
              >
                <Image
                  src={`/images/placeholders/service1.webp`}
                  alt={service.name}
                  width={100}
                  height={100}
                  className='w-24 h-24 object-cover rounded mr-4'
                  style={{ filter: filter }}
                />
                <div className=''>
                  <h3 className='font-semibold'>{service.name}</h3>
                  <p className='text-sm text-muted-foreground'>
                    {service.description}
                  </p>
                </div>
              </li>
            ))}
          </ul>
        )}
      </GlassPanel>
    </TabsContent>
  );
}
