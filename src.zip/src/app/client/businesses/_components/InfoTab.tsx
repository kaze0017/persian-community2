import React, { useState } from 'react';

import {
  GlassInput,
  GlassImageUpload,
} from '@/app/client/businesses/_components/GlassInputs';
import GlassPanel from '@/components/GlassPanel';
import MapSelector from '@/app/admin/MapSelector';
import { useForm, SubmitHandler } from 'react-hook-form';
import { Button } from '@/components/ui/button';
import { TabsContent } from '@/components/ui/tabs';
import { filter } from '@/app/components/filters/logoFilter';

export default function InfoTab({
  onSubmit,
}: {
  onSubmit: SubmitHandler<any>;
}) {
  const { register, handleSubmit, setValue } = useForm();
  const [dirty, setDirty] = useState(false);
  return (
    <TabsContent value='info'>
      <form onSubmit={handleSubmit(onSubmit)} className='space-y-6 relative'>
        <GlassPanel>
          <div className='space-y-4'>
            <h3 className='text-xl font-semibold'>Business Info</h3>
            <p className='text-sm/6 text-muted-foreground'>
              Put your general business information here (name, description,
              contact, location, hours...).
            </p>

            {/* Inputs */}
            <div className='grid grid-cols-1 md:grid-cols-2 gap-4'>
              <GlassInput
                label='Business Name'
                type='text'
                placeholder='Enter business name'
                {...register('businessName')}
                onChange={() => setDirty(true)}
              />
              <GlassInput
                label='Email'
                type='email'
                placeholder='example@email.com'
                {...register('email')}
                onChange={() => setDirty(true)}
              />
              <GlassInput
                label='Phone'
                type='tel'
                placeholder='+1 (555) 123-4567'
                {...register('phone')}
                onChange={() => setDirty(true)}
              />
              <GlassInput
                label='Address'
                type='text'
                placeholder='123 Main St'
                {...register('address')}
                onChange={() => setDirty(true)}
              />
            </div>

            {/* Map */}
            <MapSelector
              onChange={(coords, address) => {
                setValue('coordinates.lat', coords.lat);
                setValue('coordinates.lng', coords.lng);
                setValue('address', address || '');
                setDirty(true);
              }}
            />

            {/* Block with two rows */}
            <div className='grid gap-6'>
              {/* First row: two cols */}
              <div className='grid grid-cols-1 md:grid-cols-2 gap-6'>
                <GlassImageUpload
                  label='Owner Image'
                  defaultImage='/images/placeholders/owner.webp'
                  onChange={() => setDirty(true)}
                />
                <GlassImageUpload
                  label='Business Card / Logo'
                  defaultImage='/images/placeholders/logo.webp'
                  onChange={() => setDirty(true)}
                  imgStyle={filter}
                />
              </div>

              {/* Second row: banner */}
              <GlassImageUpload
                label='Business Banner'
                defaultImage='/images/placeholders/banner.webp'
                wide
                onChange={() => setDirty(true)}
              />
              <span className='text-xs text-muted-foreground'>
                Recommended size: 1200x300px
              </span>
            </div>
          </div>
        </GlassPanel>

        {/* Floating Glass Buttons */}
        {dirty && (
          <div className='sticky bottom-4 right-0 flex justify-end gap-3 px-2'>
            <Button
              type='button'
              variant='ghost'
              className='bg-white/10 backdrop-blur-md border border-white/20 text-sm shadow-lg rounded-xl'
              onClick={() => setDirty(false)}
            >
              Discard Changes
            </Button>
            <Button
              type='submit'
              className='bg-white/20 backdrop-blur-md border border-white/20 text-sm shadow-lg rounded-xl'
            >
              Save Changes
            </Button>
          </div>
        )}
      </form>
    </TabsContent>
  );
}
