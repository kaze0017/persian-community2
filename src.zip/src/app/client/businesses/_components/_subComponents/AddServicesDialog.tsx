'use client';

import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { GlassImageUpload, GlassInput } from '../GlassInputs';
import { filter } from '@/app/components/filters/logoFilter';

// Single service type
export type Service = {
  id: string;
  name: string;
  description: string;
  banner: string;
};

type Props = {
  businessId: string;
  open: boolean;
  onClose: () => void;
  onAdded: (item: Service) => void;
};

export default function AddServicesDialog({
  businessId,
  open,
  onClose,
  onAdded,
}: Props) {
  const [serviceName, setServiceName] = React.useState('');
  const [serviceDescription, setServiceDescription] = React.useState('');
  const [serviceImage, setServiceImage] = React.useState('');
  const [adding, setAdding] = React.useState(false);

  const handleAdd = () => {
    if (!serviceName.trim() || !serviceDescription.trim()) return;

    setAdding(true);

    const newService: Service = {
      id: Date.now().toString(),
      name: serviceName,
      description: serviceDescription,
      banner: serviceImage,
    };

    onAdded(newService);

    // Reset fields
    setServiceName('');
    setServiceDescription('');
    setServiceImage('');
    setAdding(false);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className='max-w-lg rounded-2xl bg-white/20 backdrop-blur-md border border-white/30'>
        <DialogHeader>
          <DialogTitle>Add New Service</DialogTitle>
        </DialogHeader>

        <div className='mt-2 flex flex-col gap-4'>
          <GlassInput
            label='Service Name'
            type='text'
            placeholder='Enter new service name'
            onChange={(e) => setServiceName(e.target.value)}
          />
          <GlassInput
            label='Service Description'
            type='text'
            placeholder='Enter new service description'
            onChange={(e) => setServiceDescription(e.target.value)}
          />
          <GlassImageUpload
            label='Service Image'
            defaultImage='/images/placeholders/service1.webp'
            onChange={() => {
              setServiceImage('./images/placeholders/service1.webp');
            }}
            wide={false}
            imgStyle={filter}
          />
        </div>

        <div className='mt-4 flex justify-end gap-2'>
          <Button onClick={onClose} variant='ghost' className='min-w-[100px]'>
            Cancel
          </Button>
          <Button
            onClick={handleAdd}
            disabled={adding}
            className='min-w-[100px]'
          >
            {adding ? 'Adding...' : 'Add Service'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
