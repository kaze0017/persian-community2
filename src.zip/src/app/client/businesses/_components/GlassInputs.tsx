export function GlassInput({
  label,
  type,
  placeholder,
  onChange,
}: {
  label: string;
  type: string;
  placeholder?: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}) {
  return (
    <label className='block'>
      <span className='text-xs uppercase tracking-wide text-foreground/80'>
        {label}
      </span>
      <input
        type={type}
        placeholder={placeholder}
        className='mt-2 w-full rounded-xl bg-white/10 dark:bg-white/5 backdrop-blur-md border border-white/20 dark:border-white/10 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-white/40'
        onChange={onChange}
      />
    </label>
  );
}

import { useState } from 'react';

export function GlassImageUpload({
  label,
  defaultImage,
  wide = false,
  onChange,
  imgStyle,
}: {
  label: string;
  defaultImage: string;
  imgStyle?: string;
  wide?: boolean;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}) {
  const [preview, setPreview] = useState<string>(defaultImage);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setPreview(url);
    }
    onChange(e);
  };

  return (
    <div className='space-y-2 flex flex-col items-center justify-center p-2'>
      <span className='text-xs uppercase tracking-wide text-foreground/80 '>
        {label}
      </span>
      <div
        className={`relative rounded-2xl bg-white/10 dark:bg-white/5 backdrop-blur-md border border-white/20 dark:border-white/10 shadow-md overflow-hidden ${
          wide ? 'h-40 w-full' : 'h-32 w-32'
        }`}
      >
        <img
          src={preview}
          alt={label}
          className='w-full h-full object-cover'
          style={{ filter: imgStyle }}
        />
        <input
          type='file'
          accept='image/*'
          className='absolute inset-0 opacity-0 cursor-pointer'
          onChange={handleFileChange}
        />
      </div>
    </div>
  );
}
