'use client';
import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card } from '@/components/ui/card';
import { Info, Package, Wrench, Palette } from 'lucide-react';
import { motion } from 'framer-motion';
import GlassPanel from '@/components/GlassPanel';
import MapSelector from '@/app/admin/MapSelector';
import { useForm, SubmitHandler } from 'react-hook-form';
import { Button } from '@/components/ui/button';
import { GlassInput, GlassImageUpload } from '../_components/GlassInputs';
import { Input } from '@/components/ui/input';
import InfoTab from '../_components/InfoTab';
import ProductsTab from '../_components/ProductsTab';
import ServicesTab from '../_components/ServicesTab';
import UiTab from '../_components/UiTab';
import { useParams } from 'next/navigation';

export default function GlassTabs() {
  const { businessId }: { businessId: string } = useParams();
  console.log('Business ID:', businessId);
  const { register, handleSubmit, setValue, formState } = useForm();
  const [dirty, setDirty] = useState(false);

  const onSubmit: SubmitHandler<any> = (data) => {
    console.log('Saving...', data);
    setDirty(false);
  };
  return (
    <div className='w-full max-w-6xl mx-auto p-4 md:p-6'>
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35 }}
        className='relative'
      >
        {/* Frosted glass wrapper */}
        <div className='rounded-2xl p-4 md:p-6 bg-white/10 dark:bg-black/20 backdrop-blur-xl border border-white/20 dark:border-white/10 shadow-xl'>
          <Tabs defaultValue='info' className='w-full'>
            <div className='flex items-center justify-between gap-4 flex-wrap'>
              <TabsList className='bg-white/10 dark:bg-white/5 backdrop-blur-md border border-white/20 dark:border-white/10 rounded-2xl p-1 shadow-sm'>
                <TabsTrigger
                  value='info'
                  className='data-[state=active]:bg-white/30 data-[state=active]:text-black dark:data-[state=active]:text-white rounded-xl'
                >
                  <Info className='mr-2 h-4 w-4' /> Info
                </TabsTrigger>
                <TabsTrigger
                  value='products'
                  className='data-[state=active]:bg-white/30 data-[state=active]:text-black dark:data-[state=active]:text-white rounded-xl'
                >
                  <Package className='mr-2 h-4 w-4' /> Products
                </TabsTrigger>
                <TabsTrigger
                  value='services'
                  className='data-[state=active]:bg-white/30 data-[state=active]:text-black dark:data-[state=active]:text-white rounded-xl'
                >
                  <Wrench className='mr-2 h-4 w-4' /> Services
                </TabsTrigger>
                <TabsTrigger
                  value='ui'
                  className='data-[state=active]:bg-white/30 data-[state=active]:text-black dark:data-[state=active]:text-white rounded-xl'
                >
                  <Palette className='mr-2 h-4 w-4' /> UI
                </TabsTrigger>
              </TabsList>
            </div>

            {/* CONTENT */}
            <div className='mt-4 md:mt-6 grid grid-cols-1'>
              <InfoTab onSubmit={onSubmit} />
              <ProductsTab businessId={businessId} />
              <ServicesTab />
              <UiTab />
            </div>
          </Tabs>
        </div>
      </motion.div>
    </div>
  );
}
